//new_detail.js
var detail = require('../detail/detail.js');
//获取应用实例
var app = getApp();
Page(detail.ipage);